# mb.containerPlus

__An open source jQuery component to easily build a windowed interface.__

![mb.containerPlus](http://pupunzi.com/images/components/mb.containerPlus.png)

## [go to the demo](http://pupunzi.com/#mb.components/mb.containerPlus/containerPlus.html)

